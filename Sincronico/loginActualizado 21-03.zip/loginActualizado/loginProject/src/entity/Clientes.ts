import { Pipe } from "stream";
import { Column, Entity, PrimaryColumn } from "typeorm";

@Entity()
export class Clientes{
    
    @PrimaryColumn()
    cedula:number
    @Column()
    apellido1:String
    @Column()
    apellido2:String
    @Column()
    email:String
    @Column({type:'date'})
    FechaNacimiento:String 
    @Column()
    estado:boolean

}