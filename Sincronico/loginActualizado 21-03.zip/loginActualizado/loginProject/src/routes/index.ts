import { Router } from "express";
import clientes from "./clientes";
import productos from "./productos";
//ruta principal del modulo
const routes=Router();

routes.use('/productos',productos);
routes.use('/clientes',clientes);

export default routes;