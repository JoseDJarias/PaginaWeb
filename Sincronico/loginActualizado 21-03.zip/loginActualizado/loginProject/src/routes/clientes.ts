import { Router } from "express";
import ClientesController from "../controller/ClientesController";

const routes=Router();

routes.get('/',ClientesController.getAll);
routes.get('/:cedula',ClientesController.getBycedula);
routes.delete('/:cedula',ClientesController.delete);
routes.post('/create',ClientesController.create);
routes.patch('/update/:id',ClientesController.update);




export default routes;