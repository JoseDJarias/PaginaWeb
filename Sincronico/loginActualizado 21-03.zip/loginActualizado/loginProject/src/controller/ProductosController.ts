import { Request, Response } from "express";
import { AppDataSource } from "../data-source";
import { Productos } from "../entity/Productos";

class ProductosController {

  static get = async (req: Request, res: Response) => {
    console.log('Hola');
    //repositorio(entidad de productos )
    const productosRepo = AppDataSource.getRepository(Productos);
    const lista = await productosRepo.find();
    if (lista.length > 0) {
      return res.status(200).json(lista);
    } else {
      return res.status(400).json({ message: 'no hay datos' })
    }
  }

  static getById = async (req: Request, res: Response) => {
    //pasar datos por id
    const productosRepo = AppDataSource.getRepository(Productos);

    const id = parseInt(req.params['id']);
    if (!id) {
      return res.status(400).json({ message: 'no se indico id' })
    }
    try {
      const producto = await productosRepo.findOneOrFail({ where: { id } })
      return res.status(200).json(producto)

    } catch (error) {
      return res.status(400).json({ message: 'no se encontro con el id' })

    }

  }

  static deleteById = async (req: Request, res: Response) => {
    //pasar datos por id
    const productosRepo = AppDataSource.getRepository(Productos);

    // Extraigo de la ruta el id enviado, lo escribo igual que lo defini en la ruta, el nombre de la const puede ser x
    const id = parseInt(req.params['id']);
    //cuando asigno una variable con let es dentro de este metodo o de lo que lo contenga no es global
    // asigno variable para verificar si existe y cambiarle de estado
    let producto: Productos;

    // compruebo  si existe el producto
    try {
      // valido si existe 
      producto = await productosRepo.findOneOrFail({ where: { id } })

    } catch (error) {
      return res.status(400).json({ message: 'no se encontro con el id' })

    }
    // si exist con el id, camvio el estado a false
    producto.estado = false; // borrado logico
    await productosRepo.save(producto);
    return res.status(200).json({ message: 'El producto se ha eliminado' })
  }



  // crear un producto desde el body del json en el postman con la palabra post 
  static create = async (req: Request, res: Response) => {

    //destructuring de los datos en el cuerpo del json
    const { id, nombre, idCategoria, precio } = req.body;

    // console.log(req.body);
    // return res.status(200).json({ message: 'Estoy en create' });


    // validar los datos de entrada, lo que viene en el cuerpo
    // regla de negocio para validar datos de entrada, campos que no permita nulos o 
    // campos que a nivel de negocio son requeridos y a nivel de bs permite nulos.
    if (!id) {
      return res.status(400).json({ message: 'Falta el ID' });
    } else if (!nombre) {
      return res.status(400).json({ message: 'Falta el Nombre' });
    } else if (!idCategoria) {
      return res.status(400).json({ message: 'Falta el IdCategoria' });
    } else if (!precio) {
      return res.status(400).json({ message: 'Falta el Precio' });
    }

    // creo instancia del repo productos
    const productosRepo = AppDataSource.getRepository(Productos);

    // valido si existe el producto con ese id
    if (await productosRepo.findOne({ where: { id } })) {

      // Respondo con error si ya existe el producto en la base de datos
      return res.status(400).json({ message: 'Ya existe un producto con ese nombre en la base de datos' });
    }

    // Creo entidad nueva enviar a guardar los datos y se setea los valores
    try {
      let producto = new Productos();
      producto.id = id;
      producto.nombre = nombre;
      producto.idCategoria = idCategoria;
      producto.precio = precio;
      producto.estado = true;

      await productosRepo.save(producto);
      return res.status(201).json({ message: 'El producto fue creado' });


    } catch (error) {
      return res.status(400).json({ message: 'Dato erroneo' });

    }




  }

  static update = async (req: Request, res: Response) => {
    //vamos a pasar el id por la url
    const id = parseInt(req.params['id']);
    const { nombre, idCategoria, precio } = req.body;

    // validar datos de entrada ()
    if (!id) {
      return res.status(400).json({ message: 'Falta el ID' });
    }else if (!nombre) {
      return res.status(400).json({ message: 'Falta el Nombre' });
    } else if (!idCategoria) {
      return res.status(400).json({ message: 'Falta el IdCategoria' });
    } else if (!precio) {
      return res.status(400).json({ message: 'Falta el Precio' });
    }

    let producto: Productos;

    const productosRepo = AppDataSource.getRepository(Productos);


    try {
      producto = await productosRepo.findOneOrFail({ where: { id } })

    } catch (error) {
      return res.status(400).json({ message: 'no se encontro con el id' })

    }
    // Caigo encima a los campos especificos
    producto.nombre=nombre;
    producto.idCategoria=idCategoria;
    producto.precio=precio;

    await productosRepo.save(producto);

    return res.status(200).json({ message: 'El producto ha sido actualizado' });

  }



}




export default ProductosController;