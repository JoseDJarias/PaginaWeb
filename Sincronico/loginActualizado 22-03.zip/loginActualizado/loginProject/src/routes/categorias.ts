import { Router } from "express";
import CategoriasController from "../controller/CategoriasController";

const routes=Router();

routes.get('/',CategoriasController.get);
routes.get('/:id',CategoriasController.getById);
routes.delete('/:id',CategoriasController.delete);
routes.post('/create',CategoriasController.create);
routes.patch('/update/:id',CategoriasController.update);
routes.patch('/undelete/:id',CategoriasController.undelete);





export default routes;