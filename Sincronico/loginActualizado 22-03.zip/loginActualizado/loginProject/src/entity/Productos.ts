import { IsInt, IsBoolean,  IsNotEmpty, IsString, MaxLength  } from "class-validator";
import { Column, Entity, ManyToOne, PrimaryColumn } from "typeorm";
import { Categorias } from "./Categorias";

@Entity()
export class Productos{
    
    @PrimaryColumn()
    @IsNotEmpty({message:'Se requiere el id'})
    @IsInt({message:'Tiene que ser un valor entero'})
    id:number

    @Column()
    @IsNotEmpty({message:'Se requiere el nombre'})   
    @IsString({message:'No es un caracter'})
    @MaxLength(50,{message:'El nombre no puede tener mas de 50 caracteres'})
    nombre:String

    // @Column()
    // @IsNotEmpty({message:'Se requiere la categoria'})
    // @IsInt({message:'Tiene que ser un valor entero'})
    // idCategoria:number

    @Column()
    @IsInt({message:'Tiene que ser entero'})
    @IsNotEmpty({message:'Se requiere el precio'})
    precio:number

    @Column()
    @IsNotEmpty({message:'Se requiere el estado'})
    @IsBoolean({message:'Tiene que ser un valor booleano'})
    estado:boolean

    //se crea una entidad dentro de la otra
    @ManyToOne(()=>Categorias,(categoria)=>categoria.productos)
    categoria: Categorias

}