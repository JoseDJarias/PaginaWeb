import { IsBoolean, IsInt, IsNotEmpty, MaxLength } from "class-validator";
import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { Productos } from "./Productos";

@Entity()
export class Categorias{
    @PrimaryGeneratedColumn()
    @IsNotEmpty({message:'Np puede estar vacio'})
    @IsInt({message:'Tiene que ser entero'})
    id:number;

    @Column()
    @IsNotEmpty({message:'Np puede estar vacio'})
    @MaxLength(50,{message:'El nombre no puede tener mas de 50 caracteres'})
    nombre:string;

    @Column()
    @IsNotEmpty({message:'Np puede estar vacio'})
    @IsBoolean({message:'Tiene que ser booleano'})
    estado:boolean

    @OneToMany(()=>Productos, (prod)=>prod.categoria )
    productos:Productos[]
}