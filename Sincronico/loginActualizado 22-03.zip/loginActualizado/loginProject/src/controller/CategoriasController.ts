import { Request, Response } from "express";
import { AppDataSource } from "../data-source";
import { Categorias } from "../entity/Categorias";
import { Productos } from "../entity/Productos";
import { validate} from "class-validator";

class  CategoriasController{

    static get= async(req:Request, res:Response)=>{

    const categoriasRepo = AppDataSource.getRepository(Categorias);

    const lista = await categoriasRepo.find({where: {estado:true}, relations:['productos']});

    if (lista.length > 0) {
      return res.status(200).json(lista);
    } else {
      return res.status(400).json({ message: 'no hay datos' })
    }
    }

    static getById = async (req: Request, res: Response) => {
        //pasar datos por id
        const categoriaRepo = AppDataSource.getRepository(Categorias);
    
        const id = parseInt(req.params['id']);
        if (!id) {
          return res.status(400).json({ message: 'no se indico id' })
        }
        try {
          const categoria = await categoriaRepo.findOneOrFail({ where: { id,estado:true }, relations:['productos'] })
          return res.status(200).json(categoria)
    
        } catch (error) {
          return res.status(400).json({ message: 'no se encontro con el id' })
    
        }
    
      }

      
  static delete = async (req: Request, res: Response) => {
    //pasar datos por id
    const categoriaRepo = AppDataSource.getRepository(Categorias);

    // Extraigo de la ruta el id enviado, lo escribo igual que lo defini en la ruta, el nombre de la const puede ser x
    const id = parseInt(req.params['id']);
    //cuando asigno una variable con let es dentro de este metodo o de lo que lo contenga no es global
    // asigno variable para verificar si existe y cambiarle de estado
    let categoria: Categorias;

    // compruebo  si existe el producto
    try {
      // valido si existe 
      categoria = await categoriaRepo.findOneOrFail({ where: { id } })

    } catch (error) {
      return res.status(400).json({ message: 'no se encontro con el id' })

    }
    // si exist con el id, cambio el estado a false
    categoria.estado = false; // borrado logico
    await categoriaRepo.save(categoria);
    return res.status(200).json({ message: 'La categoria se ha eliminado' })
  }

  static create = async (req: Request, res: Response) => {

    //destructuring de los datos en el cuerpo del json
    const { id, nombre,estado } = req.body;

    // console.log(req.body);
    // return res.status(200).json({ message: 'Estoy en create' });


    // validar los datos de entrada, lo que viene en el cuerpo
    // regla de negocio para validar datos de entrada, campos que no permita nulos o 
    // campos que a nivel de negocio son requeridos y a nivel de bs permite nulos.
    if (!id) {
      return res.status(400).json({ message: 'Falta el ID' });}
  

    // creo instancia del repo productos
    // const productosRepo = AppDataSource.getRepository(Productos);
    const categoriaRepo = AppDataSource.getRepository(Categorias);


    // valido si existe el producto con ese id
    if (await categoriaRepo.findOne({ where: { id } })) {

      // Respondo con error si ya existe el producto en la base de datos
      return res.status(400).json({ message: 'Ya existe una categoria con ese id en la base de datos' });
    }

    

    // Creo entidad nueva enviar a guardar los datos y se setea los valores
      let categoria = new Categorias();
      categoria.id = id;
      categoria.nombre = nombre;
      categoria.estado = estado;

      //valido con el class validator
      const error= await validate(categoria,{validationError:{target:false,value:false}});
      if(error.length>0){
        return res.status(400).json(error);
      }
 
      await categoriaRepo.save(categoria);
      return res.status(201).json({ message: 'La categoria fue creado' });


    }

    
  static update = async (req: Request, res: Response) => {
    //vamos a pasar el id por la url
    const id = parseInt(req.params['id']);
    const { nombre,estado } = req.body;

    // validar datos de entrada ()
    if (!id) {
      return res.status(400).json({ message: 'Falta el ID' });}
    

    let categoria: Categorias;


    const categoriaRepo = AppDataSource.getRepository(Categorias);

    try {
      categoria = await categoriaRepo.findOneOrFail({ where: { id } })

    } catch (error) {
      return res.status(400).json({ message: 'no se encontro con el id' })

    }


    // Caigo encima a los campos especificos
    categoria.nombre=nombre;

    //valido con el class validator
    const error= await validate(categoria,{validationError:{target:false,value:false}});
    if(error.length>0){
      return res.status(400).json(error);
    }

    await categoriaRepo.save(categoria);

    return res.status(200).json({ message: 'La categroia ha sido actualizado' });

  }
    
  // habilitar categoria luego de que se haya borrado logicamente
  static undelete = async (req: Request, res: Response) => {
    //vamos a pasar el id por la url
    const id = parseInt(req.params['id']);

    const categoriaRepo = AppDataSource.getRepository(Categorias);
    
    let categoria: Categorias;

    // compruebo  si existe el producto
    try {
      // valido si existe 
      categoria = await categoriaRepo.findOneOrFail({ where: { id } })

    } catch (error) {
      return res.status(400).json({ message: 'no se encontro con el id' })

    }
    // si exist con el id, cambio el estado a false
    categoria.estado = true; // borrado logico, lo cambiamos a true
    await categoriaRepo.save(categoria);
    return res.status(200).json({ message: 'La categoria se ha habilidato' })

  }



    
    

} //end class

export default CategoriasController;