import { Request, Response } from "express";
import { AppDataSource } from "../data-source";
import { Clientes } from "../entity/Clientes";


class ClientesController{

  static getAll = async (req: Request, res: Response) => {
    //repositorio(entcedulaad de productos )
    const clientesRepo = AppDataSource.getRepository(Clientes);
    const lista = await clientesRepo.find({where:{estado:true}});
    if (lista.length > 0) {
      return res.status(200).json(lista);
    } else {
      return res.status(400).json({ message: 'no hay clientes' })
    }
  }

  
  static getBycedula = async (req: Request, res: Response) => {
    //pasar datos por cedula
    const clientesRepo = AppDataSource.getRepository(Clientes);
    const cedula = parseInt(req.params['cedula']);
    if (!cedula) {
      return res.status(400).json({ message: 'no se indico cedula' })
    }
    try {
      const cliente = await clientesRepo.findOneOrFail({ where: { cedula, estado: true } })
      return res.status(200).json(cliente)

    } catch (error) {
      return res.status(400).json({ message: 'no se encontro ninguna cedulaenticacion' })

    }

  }

  static delete = async (req: Request, res: Response) => {
    //pasar datos por cedula
    const clientesRepo = AppDataSource.getRepository(Clientes);

    const cedula = parseInt(req.params['cedula']);
    //cuando asigno una variable con let es dentro de este metodo o de lo que lo contenga no es global
    let cliente:Clientes;

    try {
       cliente = await clientesRepo.findOneOrFail({ where: { cedula } })

    } catch (error) {
      return res.status(400).json({ message: 'no se encontro con el cedula' })

    }

    cliente.estado=false;
    await clientesRepo.save(cliente);
    return res.status(200).json({message:'El producto se ha eliminado'})
  }


    // crear un producto desde el body del json en el postman con la palabra post 
    static create = async (req: Request, res: Response) => {

      //destructuring de los datos en el cuerpo del json
      const { cedula, apellido1, apellido2, email, FechaNacimiento } = req.body;
  
      // console.log(req.body);
      // return res.status(200).json({ message: 'Estoy en create' });
  
  
      // validar los datos de entrada, lo que viene en el cuerpo
      // regla de negocio para validar datos de entrada, campos que no permita nulos o 
      // campos que a nivel de negocio son requeridos y a nivel de bs permite nulos.
      if (!cedula) {
        return res.status(400).json({ message: 'Falta el ID' });
      } else if (!apellido1) {
        return res.status(400).json({ message: 'Falta el primer apellido' });
      } else if (!apellido2) {
        return res.status(400).json({ message: 'Falta el segundo apellido' });
      }else if (!email) {
        return res.status(400).json({ message: 'Falta la fecha de nacimiento' });
      }else if (!FechaNacimiento) {
        return res.status(400).json({ message: 'Falta el Precio' });
      }
  
      // creo instancia del repo clientes
      const clientesRepo = AppDataSource.getRepository(Clientes);
  
      // valido si existe el producto con ese id
      if (await clientesRepo.findOne({ where: { cedula } })) {
  
        // Respondo con error si ya existe el producto en la base de datos
        return res.status(400).json({ message: 'Ya existe un producto con ese nombre en la base de datos' });
      }
  
      // Creo entidad nueva enviar a guardar los datos y se setea los valores
      try {
        let cliente = new Clientes();
        cliente.cedula = cedula;
        cliente.apellido1 = apellido1;
        cliente.apellido2 = apellido2;
        cliente.email = email;
        cliente.FechaNacimiento = FechaNacimiento;
        cliente.estado = true;
  
        await clientesRepo.save(cliente);
        return res.status(201).json({ message: 'El cliente fue creado' });
  
  
      } catch (error) {
        return res.status(400).json({ message: 'Dato erroneo' });
  
      }
  
  
  
  
    }
    // en este caso para actualizar un producto ocupamos la url y en el cuerpo modificamos 
    // los campos exepto el id y el estado
    static update = async (req: Request, res: Response) => {
      //vamos a pasar el id por la url
      //el req.params hace una peticion al servidor, enviando la url de lo que se busca en
      // este caso seria la cedula
      const cedula = parseInt(req.params['cedula']);
      const { apellido1, apellido2, email, FechaNacimiento } = req.body;
  
      //validar datos de entrada ()
      if (!cedula) {
        return res.status(400).json({ message: 'Falta el ID' });
      }else if (!apellido1) {
        return res.status(400).json({ message: 'Falta el primer apellido' });
      } else if (!apellido2) {
        return res.status(400).json({ message: 'Falta el segundo apellido' });
      }else if (!email) {
        return res.status(400).json({ message: 'Falta la fecha de nacimiento' });
      }else if (!FechaNacimiento) {
        return res.status(400).json({ message: 'Falta el Precio' });
      }
      let cliente: Clientes;
      //necesitamos el repositorio de clientes 
      const clientesRepo = AppDataSource.getRepository(Clientes);
  
  
      try {
        //asignamos una var que sea la espera del repositorio y que esta busque una o falle
        // busque que? que los datos que mando por el rep.body no sean iguales a los que ya tenemos
        cliente = await clientesRepo.findOneOrFail({ where: { cedula } })
  
      } catch (error) {
        return res.status(400).json({ message: 'no se encontro con el id' })
  
      }
      // Caigo encima a los campos especificos que quiero actualizar 
      cliente.apellido1=apellido1;
      cliente.apellido2=apellido2;
      cliente.email=email;
      cliente.FechaNacimiento=FechaNacimiento;
      
      //guardo los cambios
      await clientesRepo.save(cliente);
      
      return res.status(200).json({ message: 'El producto ha sido actualizado' });
  
    }
  
  


}


export default ClientesController